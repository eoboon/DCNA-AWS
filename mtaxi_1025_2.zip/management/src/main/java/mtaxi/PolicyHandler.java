package mtaxi;

import mtaxi.config.kafka.KafkaProcessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class PolicyHandler{
    @StreamListener(KafkaProcessor.INPUT)
    public void onStringEventListener(@Payload String eventString){

    }

    @Autowired
    ManagementRepository managementRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverOrdered_RequestConfirmOrder(@Payload Ordered ordered){

        if(ordered.isMe()){
            System.out.println("##### listener RequestConfirmOrder : " + ordered.toJson());
            Management management = new Management();

            management.setStatus("Ordered");
            management.setDriverId(ordered.getDriverId());
            management.setOrderId(ordered.getOrderId());
            management.setLocation(ordered.getLocation());

            managementRepository.save(management);
        }
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverOrderAgreed_StatusChange(@Payload OrderAgreed orderAgreed){

        if(orderAgreed.isMe()){
            System.out.println("##### listener StatusChange : " + orderAgreed.toJson());
        }
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverOrderDeclined_StatusChange(@Payload OrderDeclined orderDeclined){

        if(orderDeclined.isMe()){
            System.out.println("##### listener StatusChange : " + orderDeclined.toJson());
        }
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverOrderCanceled_RequestCancelOrder(@Payload OrderCanceled orderCanceled){

        if(orderCanceled.isMe()){
            System.out.println("##### listener RequestCancelOrder : " + orderCanceled.toJson());
        }
    }

}
